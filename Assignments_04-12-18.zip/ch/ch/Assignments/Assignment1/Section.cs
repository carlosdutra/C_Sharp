﻿using Assignment1.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Section
    {
        public string sectionId { get; set; }
        public string name { get; set; }
        public int maxNoOfStudents { get; set; }
        public Semester semester { get; set; }
        public int noOfEvaluations { get; set; }
        public string faculty { get; set; }

        public Section(int maxNoOfStudents, Semester semester)
        {
            this.maxNoOfStudents = maxNoOfStudents;
            this.semester = semester;
        }

        public string GetInfo()
        {
            return $"SectionId = {sectionId}\n" +
                $"Name = {name}\n" +
                $"MaxNoOfStudents = {maxNoOfStudents}\n" +
                $"Semester = {semester}\n" +
                $"NoOfEvaluations = {noOfEvaluations}\n" +
                $"Faculty = {faculty}";
        }
    }
}
