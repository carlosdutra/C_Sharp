﻿using Assignment3A.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    [Serializable]

    public class Enrolment
    {
        #region FIELDS
        public Person student { get; set; }
        public Section section = new Section();
        public Grade finalGrade { get; set; }
        public int numberOfEvaluations { get; }
        public int currentNumOfEvaluations = 0;
        public Evaluation[] evaluations { get; set; }
        #endregion

        //CONSTRUCTOR
        public Enrolment(Person student, Section section, Grade finalGrade, 
            int numberOfEvaluations)
        {
            this.student = student;
            this.section = section;
            this.finalGrade = finalGrade;
            this.numberOfEvaluations = numberOfEvaluations;
            this.evaluations = new Evaluation[section.Course.NoOfEvaluations];
        }

        #region METHODS
        //Letter Percentage	4.5 Scale
        //A+	90-100	4.5
        //A	    80-89	4
        //B+	75-79	3.5
        //B	    70-74	3
        //C+	65-69	2.5
        //C	    60-64	2
        //D+	55-59	1.5
        //D	    50-54	1
        //F	    0-49	0

        public Grade CalculateFinalGrade()
        {
            double gradeTotal = 0.0d;

            for (int j = 0; j < section.currentNumOfEvaluations; j++)
            {
                gradeTotal += ((evaluations[j].points / evaluations[j].maxPoints) * evaluations[j].evaluationWeight) * 100;   //(points / maxPoints) * weight;
            }

            if (gradeTotal <= 49)
                finalGrade = Grade.F;
            else if (gradeTotal <= 54)
                finalGrade = Grade.D;
            else if (gradeTotal <= 59)
                finalGrade = Grade.D_Plus;
            else if (gradeTotal <= 64)
                finalGrade = Grade.C;
            else if (gradeTotal <= 69)
                finalGrade = Grade.C_Plus;
            else if (gradeTotal <= 74)
                finalGrade = Grade.C_Plus;
            else if (gradeTotal <= 79)
                finalGrade = Grade.B_Plus;
            else if (gradeTotal <= 89)
                finalGrade = Grade.A;
            else
                finalGrade = Grade.A_Plus;

            return finalGrade;
        }

        public string GetInfo()
        {
            return $"Student = {student}\n" +
                $"Section = {section}\n" +
                $"FinalGrade = {finalGrade}";
        }
        #endregion
    }
}