﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Person
    {
        public int registrationNumber { get; }
        public string name { get; set; }
        public DateTime dob { get; set; }
        public Address address { get; set; }
        public string telephoneNumber { get; set; }

        public Person(int registrationNumber, string name, DateTime dob)
        {
            this.registrationNumber = registrationNumber;
            this.name = name;
            this.dob = dob;
        }

        public string GetInfo()
        {
            return $"RegistrationNumber = {registrationNumber}\n" +
                $"Name = {name}\n" +
                $"Dob = {dob}\n" +
                $"Address = {address}\n" +
                $"TelephoneNumber = {telephoneNumber}";
        }

    }
}
