﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    [Serializable]

    public class Person
    {
        static int regCounter = 0;
        public int registrationNumber { get; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public Address Address { get; set; }
        public uint TelephoneNumber { get; set; }

        public Person()
        {
            //Creating Registration Number everytime the constructor is called
            regCounter++;
            registrationNumber = regCounter;
        }

        public Person(string name, DateTime dOB)
        {
            Name = name;
            DOB = dOB;

            //Creating Registration Number everytime the constructor is called
            regCounter++;
            registrationNumber = regCounter;
        }

        public Person(int registrationNumber, string name, DateTime dob)
        {
            this.registrationNumber = registrationNumber;
            this.Name = name;
            this.DOB = dob;

            //Creating Registration Number everytime the constructor is called
            regCounter++;
            registrationNumber = regCounter;

        }

        public string GetInfo()
        {
            return $"RegistrationNumber = {registrationNumber}\n" +
                $"Name = {Name}\n" +
                $"Dob = {DOB}\n" +
                $"Address = {Address.streetName}, {Address.city}, {Address.province}\n" +
                $"TelephoneNumber = {TelephoneNumber}";
        }

    }
}
