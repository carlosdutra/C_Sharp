﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment3A;
using Assignment3A.Enums;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void AddStudentMark_PointsGreaterThanMaxPoints_ThrowAnError()
        {
            //Arrange
            Person student = new Person();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section() { Course = testCourse };

            //Act
            aSection.AddStudent(student);
            aSection.DefineEvaluation(1, EvaluationType.TEST, 100, .5);

            try
            {
                aSection.AddStudentMark(1, student, 101);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Section.PointsAreGreaterThanMaxPoints);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void AddStudent_TryingToAddStudentToFullSection_ThrowAnError()
        {
            //Arrange
            Person student1 = new Person();
            Person student2 = new Person();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section()
            {
                Course = testCourse,
                MaxNumberOfStudents = 1
            };

            //Act
            aSection.AddStudent(student1);

            try
            {
                aSection.AddStudent(student2);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Section.SectionIsFull);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void CalculateGrade_WithValidValues_ShouldReturnValueExpected()
        {
            //Arrange
            Section aSection = new Section();
            double expected = 0.528d;

            //Act
            double actual = aSection.CalculateGrade(88, 100, .6);

            //Assert
            Assert.AreEqual(expected, actual, 0.001, "Grade was calculated correctly!");
        }

        [TestMethod]
        public void CalculateFinalGrade_StudentWithGradesA_ShouldReturnGradeA()
        {
            //Arrange
            Person student = new Person();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section() { Course = testCourse };
            Enrolment aEnrolment = new Enrolment(student, aSection, Grade.NO_GRADE, 3);
            Grade expected = Grade.A;

            //Act
            aSection.AddStudent(student);

            aSection.DefineEvaluation(1, EvaluationType.TEST, 100, .5);
            aSection.DefineEvaluation(2, EvaluationType.LAB, 80, .3);
            aSection.DefineEvaluation(3, EvaluationType.QUIZ, 20, 0.2);

            aSection.AddStudentMark(1, student, 90);
            aSection.AddStudentMark(2, student, 70);
            aSection.AddStudentMark(3, student, 15);

            Grade actual = aSection.Enrolments[0].CalculateFinalGrade(); //Calculate the Final Grade

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AddSection_SectionWithIdAndNameNulls_ShouldThrownAnException()
        {
            //Arrange
            Person student = new Person();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section();

            //Act
            try
            {
                testCourse.AddSection(aSection);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Course.SectionIsNotValid);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void AddSection_TryToAddSectionAlreadyAssignedToAnotherCourse_ShouldThrownAnException()
        {
            //Arrange
            Person student = new Person();
            Course testCourse = new Course()
            {
                Name = "COURSE_TEST",
                NoOfEvaluations = 3
            };
            Course testCourse1 = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section()
            {
                Name = "SECTION_TEST",
                SectionId = "ID_TEST",
                Course = testCourse
            };

            //Act
            try
            {
                testCourse1.AddSection(aSection);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Course.SectionIsAlreadyAssignedToAnotherCourse);
                return;
            }

            //Assert
            Assert.Fail();
        }

    }
}
