﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Enums
{
    public enum Grade
    {
        NO_GRADE,
        F,
        D,
        D_Plus,
        C_Minus,
        C,
        C_Plus,
        B_Minus,
        B,
        B_Plus,
        A_Minus,
        A, 
        A_Plus
    }
}
