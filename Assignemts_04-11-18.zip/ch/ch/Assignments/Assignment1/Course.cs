﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Course
    {
        public int code { get; set; }
        public string name { get; set; }
        public string description { get; set; }

        public Course(int code, string name)
        {
            this.code = code;
            this.name = name;
        }

        public string GetInfo()
        {
            return $"Code = {code}\n" +
                $"Name = {name}\n" +
                $"Description = {description}";
        }
    }
}
