﻿using Assignment2.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Course
    {
        #region FIELDS
        private string courseCode;
        private string name;
        private string description;
        private int noOfEvaluations;
        public Section[] sections; //4.a
        private int maxNumberOfSections = 20;
        private readonly int numberOfSections; //4.b
        private int currentNumberOfSections = 0;
        #endregion

        #region PROPERTIES
        
        public string CourseCode
        {
            get { return courseCode; }
            set { courseCode = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int NoOfEvaluations
        {
            get { return noOfEvaluations; }
            set { noOfEvaluations = value; }
        }

        public int NumberOfSections
        {
            get { return numberOfSections; }
        }

        public Section[] Sections
        {
            get { return sections; }
            set { sections = value; }
        }


        #endregion

        #region CONSTRUCTORS        
        public Course()
        {
            sections = new Section[maxNumberOfSections];
            numberOfSections++;
        }

        public Course(string courseCode, string name)
        {
            sections = new Section[maxNumberOfSections];
            numberOfSections++;

            CourseCode = courseCode;
            Name = name;
        }
        #endregion

        public void AddSection(SemesterPeriod semesterPeriod, string SectionId, string sectionName) //4.c.i
        {
            Section newSection = new Section(30, semesterPeriod);
            newSection.SectionId = SectionId;
            newSection.Name = sectionName;

            
            // Add to sections
            
            sections[currentNumberOfSections] = newSection;
            currentNumberOfSections++;

            newSection.Course = this;
        }

        public void AddSection(Section newSection)
        {
            // Add to sections            
            sections[currentNumberOfSections] = newSection;
            currentNumberOfSections++;
            newSection.Course = this;

            #region validations

            // Validation 1
            if (newSection.SectionId == null || newSection.SectionId == null)
            {
                throw new Exception("\nSection is not valid");
            }

            else
            {
                // Validation 2
                bool exists = false;
                //foreach (Section section in sections)
                for (int i = 0; i < Sections.Length; i++)
                {
                    if (Sections[i].SectionId == newSection.SectionId)
                    {
                        exists = true;
                        break;
                    }
                }
                if (exists)
                {
                    throw new Exception("\nSection already assigned to " + $"{Name}" + " course");
                }

                //Validation3
                for (int i = 0; i < Sections.Length; i++)
                {
                    if (Sections[i].Course != null)
                    {
                        throw new Exception("\nSection is already assigned. Number of evaluations cannot be changed anymore”");
                    }

                    #endregion
                }
            }
        }

        public string GetInfo()
        {
            return String.Format("\nCourse Code: {0}, Name: {1}, Description: {2}, No. of Evaluations: {3}, No. of Sections: {4}", CourseCode, Name, Description, NoOfEvaluations, NumberOfSections);
        }
    }
}
