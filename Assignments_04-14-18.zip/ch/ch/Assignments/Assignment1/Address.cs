﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    public struct Address
    {
        string streetName;
        string unitNumber;
        string postalCode;

        public Address(string streetName, string unitNumber, string postalCode)
        {
            this.streetName = streetName;
            this.unitNumber = unitNumber;
            this.postalCode = postalCode;
        }
    }
}
