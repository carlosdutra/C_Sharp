﻿using Assignment2.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Section
    {
        private string sectionId;
        private string name;
        private int maxNumberOfStudents = 40;
        public SemesterPeriod Semester;
        private Person faculty = new Person();
        private Course course = new Course();
        private Enrolment[] enrolments = new Enrolment[40];
        private readonly int enrolmentsNumber; //5d
        private int currentNumberOfEnrolments = 0;
        public int currentNumOfEvaluations = 0;
        //public int order;
        public int counterAddStudentMark = 0;

        #region PROPERTIES
        
        public string SectionId
        {
            get { return sectionId; }
            set { sectionId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int MaxNumberOfStudents
        {
            get { return maxNumberOfStudents; }
            set { maxNumberOfStudents = value; }
        }

        public Person Faculty
        {
            get { return faculty; }
            set { faculty = value; }
        }

        public Course Course
        {
            get { return course; }
            set { course = value; }
        }


        #endregion

        
        
        public Section()
        {
            SectionId = null;
            Name = null;
            MaxNumberOfStudents = 40;
            Semester = SemesterPeriod.UNDEFINED;
            Faculty = null;
            Course = null;
            enrolments = new Enrolment[maxNumberOfStudents];
            enrolmentsNumber++;
        }

        public Section(Course course, int maxNumberOfStudents, SemesterPeriod semester)
        {
            this.Course = course;
            this.MaxNumberOfStudents = maxNumberOfStudents;
            this.Semester = semester;

            enrolments = new Enrolment[maxNumberOfStudents];
            enrolmentsNumber++;

        }

        public Section(int maxNumberOfEnrollments, SemesterPeriod semester)
        {
            // 2.c.
            if (maxNumberOfEnrollments == 0)
                maxNumberOfEnrollments = 40;

            this.MaxNumberOfStudents = maxNumberOfEnrollments;
            this.Semester = semester;

            enrolments = new Enrolment[maxNumberOfStudents];
        }

        public void AddStudent(Person student)
        {
            Enrolment newEnrolment = new Enrolment(student, this, Grade.NO_GRADE, Course.NoOfEvaluations);
            
            // TODO checks 5.e.
            //bool exists = false;
            //foreach (Enrolment enrolment in enrolments)
            //{
            //    if (enrolment.section.)
            //}

            enrolments[currentNumberOfEnrolments] = newEnrolment;
            currentNumberOfEnrolments++;
        }

        public void DefineEvaluation(int order, EvaluationType type, int maxPoints, double weight)
        {
            //this.order = order;

            for (int i=0; i < currentNumberOfEnrolments; i++)
            {
                enrolments[i].evaluations[order - 1] = new Evaluation(type, weight, maxPoints);
            }

            currentNumOfEvaluations++;
        }
        
        //TO CONTINUE
        public void AddStudentMark(int order, Person student, int points)
        {


            if (points > enrolments[order - 1].evaluations[order - 1].maxPoints)
            {
                throw new Exception("Points are more than the max number of points for the evaluation");
            }
            else
            {
                for (int i = 0; i < enrolments.Length; i++)
                {
                    if (enrolments[i] == null)
                        break;
                    else if (enrolments[i].student.registrationNumber == student.registrationNumber)
                    {
                        enrolments[i].evaluations[order - 1].points = points;
                    }
                    
                }
                //counterAddStudentMark++;
            }
                       
            
            //if (student != enrolments[currentNumberOfEnrolments].student)
            //{
            //    throw new Exception("Student" + $"{student}" + "is not in the section");
            //}
                        
        }

        public string GetEvaluationsInfo()
        {
            string text = "";
            int a = 0;

            for (int j = 0; j < currentNumOfEvaluations; j++)
            {
                text += $"\t{j}." + $"{enrolments[a].evaluations[j].type}" + $"[{enrolments[a].evaluations[j].maxPoints}]\t";
            }

            for (int j = 0; j < currentNumOfEvaluations; j++)
            {
                text += $"\n{enrolments[a].student.Name}" + $"\t{enrolments[a].evaluations[j].points}/" + $"{enrolments[a].evaluations[j].points * enrolments[a].evaluations[j].evaluationWeight}";
            }

            a++;

            return text;
        }

        public string FinalMarksInfo()
        {
            return "";
        }



        //public string PrintStudents()
        //{
        //    string text;

        //    for (int i = 0; i < currentNumberOfEnrolments; i++)
        //    {
                
        //        text += String.Format("\n" + enrolments[i].student.Name);
        //    }

        //    return text;
        //}

        public string GetInfo()
        {
            if (Faculty != null)
            {
                return String.Format("\nSection Id:{0}, Name: {1}, Max no. of Students: {2}, Semester: {3}, Faculty: {4}\n"
                      , SectionId, Name, MaxNumberOfStudents, Semester, Faculty.Name);
                

            }
            else
                return String.Format("\nSection Id:{0}, Name: {1}, Max no. of Students: {2}, Semester: {3}, Faculty: "
                     , SectionId, Name, MaxNumberOfStudents, Semester);
                        
        }

            
    }
}

