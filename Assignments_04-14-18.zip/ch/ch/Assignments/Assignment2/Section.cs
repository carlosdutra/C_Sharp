﻿using Assignment2A.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2A
{
    class Section
    {
        public string SectionId { get; set; }
        public string Name { get; set; }
        public int MaxNumberOfStudents { get; set; }
        public SemesterPeriod Semester { get; set; }        
        public Person Faculty { get; set; }
        public Course Course { get; set; }
        public Enrolment[] enrolments = new Enrolment[100];
        private int enrolmentsNumber = 0;
        

        public Section()
        {
        }

        public Section(Course course, int maxNumberOfStudents, SemesterPeriod semester) 
            : this(maxNumberOfStudents, semester)
        {
            Course = course;
        }

        public Section(int maxNumberOfStudents, SemesterPeriod semester)
        {
            // 2.c.
            if (maxNumberOfStudents == 0)
                maxNumberOfStudents = 40;

            this.MaxNumberOfStudents = maxNumberOfStudents;
            this.Semester = semester;
        }

        public void AddStudent(Person student)
        {
            Enrolment newEnrolment = new Enrolment(student, this, Grade.NO_GRADE, 0);

            // TODO checks 5.e.
            //bool exists = false;
            //foreach (Enrolment enrolment in enrolments)
            //{
            //    if (enrolment.section.)
            //}

            enrolments[enrolmentsNumber++] = newEnrolment;
        }

        public void DefineEvaluation(int order, EvaluationType type, int maxPoints, double weight)
        {
            Evaluation aEvaluation = new Evaluation(type, weight, maxPoints);

            
        }

        public string GetEvaluationsInfo()
        {
            return "";
        }

        public void AddStudentMark(int order, Person student, int points)
        {

        }

        public string FinalMarksInfo()
        {
            return "";
        }

        public string GetInfo()
        {
            return $"SectionId = {SectionId}\n" +
                $"Name = {Name}\n" +
                $"MaxNoOfStudents = {MaxNumberOfStudents}\n" +
                $"Semester = {Semester}\n" +                
                $"Faculty = {Faculty}";
        }
    }
}
