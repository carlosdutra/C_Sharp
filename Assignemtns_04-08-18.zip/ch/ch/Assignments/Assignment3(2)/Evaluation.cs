﻿using Assignment2.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Evaluation
    {
        public EvaluationType type { get; set; }
        public double evaluationWeight { get; set; }
        public double maxPoints { get; set; }
        public double points { get; set; }

        public Evaluation(EvaluationType type, double evaluationWeight, double maxPoints)
        {
            this.type = type;
            this.evaluationWeight = evaluationWeight;
            this.maxPoints = maxPoints;
        }

        public string GetInfo()
        {
            return $"Type = {type}\n" +
                $"EvaluationWeight = {evaluationWeight}\n" +
                $"MaxPoints = {maxPoints}\n" +
                $"Points = {points}";
        }
    }

}
