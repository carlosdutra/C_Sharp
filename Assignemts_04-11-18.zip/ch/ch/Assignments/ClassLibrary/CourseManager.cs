﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

namespace Assignment3A
{
    [Serializable]

    public class CourseManager
    {
        #region FIELDS
        public Course[] Courses = new Course[100];
        private int numberOfCourses;
        #endregion

        #region PROPERTIES
        public int NumberOfCourses
        {
            get { return numberOfCourses; }
        }
        #endregion

        #region CONSTRUCTORS
        public CourseManager()
        {
            numberOfCourses = 0;
        }
        #endregion

        #region METHODS
        public void AddCourse(Course aCourse)
        {
            Courses[numberOfCourses++] = aCourse;
        }

        public void ExportCourses(string filename, char delimiter)
        {
            FileStream fileOut = new FileStream(filename, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(fileOut);

            foreach (Course course in Courses)
            {
                if (course == null)
                {
                    continue;
                }
                writer.Write("{0}{1}", course.CourseCode, delimiter);
                writer.Write("{0}{1}", course.Name, delimiter);
                writer.Write("{0}{1}", course.Description, delimiter);
                writer.WriteLine("{0}", course.NoOfEvaluations);
            }

            writer.Flush();
            writer.Close();
            fileOut.Close();
        }
                
        public void SaveSchoolInfo()
        {
            FileStream fileOut = null;
            try
            {
                BinaryFormatter binFormatter = new BinaryFormatter();
                fileOut = new FileStream("user.dat", FileMode.Create, FileAccess.Write);

                binFormatter.Serialize(fileOut, Courses);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex);
            }
            finally
            {
                if (fileOut != null)
                fileOut.Close();
            }
        }

        public void LoadSchool(string filename)
        {
            FileStream fileRead = null;
            try
            {
                BinaryFormatter binFormatter = new BinaryFormatter();
                fileRead = new FileStream(filename, FileMode.Open, FileAccess.Read);
                int i = 0;

                Courses = (Course[])binFormatter.Deserialize(fileRead);

                while (Courses[i] != null)
                {
                    i++;
                }
                this.numberOfCourses = i;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0})", ex);
            }
            finally
            {
                if (fileRead != null)
                    fileRead.Close();
            }
        }

        public void ImportCourses(string filename, char delimiter)
        {
            string[] lines = File.ReadAllLines(filename);

            //int counter = 0;

            bool exists = false;
            bool result = false;
            int numOfCoursesCreated = 0;
            int linePosition = 0;

            try
            {
                foreach (string line in lines)
                {
                    linePosition++;
                    string[] dataEntries = line.Split(delimiter);

                    if (dataEntries.Length == 4)
                    {
                        //Make sure of No. Of Evaluations is a integer
                        int parseDataEntrie;
                        result = Int32.TryParse(dataEntries[3], out parseDataEntrie);

                        for (int i = 0; i < numberOfCourses; i++)
                        {
                            exists = false;

                            if (dataEntries[0] == Courses[i].CourseCode)
                            {
                                exists = true;
                                //break;
                            }
                        }
                        if (exists)
                        {
                            Console.WriteLine("Course code in record#" + $"{linePosition}: {line}" + " is in use");
                        }
                        else if (!result)
                        {
                            Console.WriteLine("Number of evaluations in record#" + $"{linePosition}: {line}" + "is not in correct format\n");

                        }
                        else
                        {
                            Courses[numberOfCourses] = new Course(dataEntries[0], dataEntries[1]);
                            Courses[numberOfCourses].Description = dataEntries[2];
                            Courses[numberOfCourses].NoOfEvaluations = Convert.ToInt32(dataEntries[3]);
                            numberOfCourses++;
                            numOfCoursesCreated++;
                        }
                    }
                    else
                        Console.WriteLine("\nInvalid number of fields in record#" + $"{linePosition}: {line}\n");

                }//endForeach
            }//endTry
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex);
            }

            Console.WriteLine("{0} records processed, {1} courses added", NumberOfCourses + 1, numOfCoursesCreated);
        }

        #endregion

    }
}