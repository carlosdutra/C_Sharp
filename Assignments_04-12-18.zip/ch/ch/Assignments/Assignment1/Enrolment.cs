﻿using Assignment1.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Enrolment
    {
        public string student { get; set; }
        public Section section { get; set; }
        public Grade finalGrade { get; set; }

        public Enrolment(string student, Section section)
        {
            this.student = student;
            this.section = section;
        }

        public string GetInfo()
        {
            return $"Student = {student}\n" +
                $"Section = {section}\n" +
                $"FinalGrade = {finalGrade}";
        }

    }
}
