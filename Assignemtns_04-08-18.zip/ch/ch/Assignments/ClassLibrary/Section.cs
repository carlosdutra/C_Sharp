﻿using Assignment3A.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    [Serializable]

    public class Section
    {
        #region FIELDS
        private string sectionId;
        private string name;
        private int maxNumberOfStudents = 40;
        public SemesterPeriod Semester;
        private Person faculty = new Person();
        private Course course = new Course();
        private Enrolment[] enrolments = new Enrolment[40];
        private readonly int enrolmentsNumber; //5d
        private int currentNumberOfEnrolments = 0;
        public int currentNumOfEvaluations = 0;
        #endregion

        #region PROPERTIES

        public string SectionId
        {
            get { return sectionId; }
            set { sectionId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int MaxNumberOfStudents
        {
            get { return maxNumberOfStudents; }
            set { maxNumberOfStudents = value; }
        }

        public Person Faculty
        {
            get { return faculty; }
            set { faculty = value; }
        }

        public Course Course
        {
            get { return course; }
            set { course = value; }
        }


        #endregion

        #region CONSTRUCTORS
        public Section()
        {
            SectionId = null;
            Name = null;
            MaxNumberOfStudents = 40;
            Semester = SemesterPeriod.UNDEFINED;
            Faculty = null;
            Course = null;
            enrolments = new Enrolment[maxNumberOfStudents];
        }

        public Section(Course course, int maxNumberOfStudents, SemesterPeriod semester)
        {
            this.Course = course;
            this.MaxNumberOfStudents = maxNumberOfStudents;
            this.Semester = semester;

            enrolments = new Enrolment[maxNumberOfStudents];

        }

        public Section(int maxNumberOfEnrollments, SemesterPeriod semester)
        {
            // 2.c.
            if (maxNumberOfEnrollments == 0)
                maxNumberOfEnrollments = 40;

            this.MaxNumberOfStudents = maxNumberOfEnrollments;
            this.Semester = semester;

            enrolments = new Enrolment[maxNumberOfStudents];
        }
        #endregion

        #region METHODS

        public void AddStudent(Person student)
        {
            Enrolment newEnrolment = new Enrolment(student, this, Grade.NO_GRADE, Course.NoOfEvaluations);
                        
            if (currentNumberOfEnrolments + 1 > MaxNumberOfStudents)
                throw new Exception("Student cannot be added. The section is full!");
            else
            {
                enrolments[currentNumberOfEnrolments++] = newEnrolment;
            }
        }

        public void DefineEvaluation(int order, EvaluationType type, int maxPoints, double weight)
        {
            for (int i = 0; i < currentNumberOfEnrolments; i++)
            {
                enrolments[i].evaluations[order - 1] = new Evaluation(type, weight, maxPoints);
            }

            currentNumOfEvaluations++;
        }
        
        public void AddStudentMark(int order, Person student, int points)
        {
            if (points > enrolments[order - 1].evaluations[order - 1].maxPoints)
            {
                throw new Exception("Points are more than the max number of points for the evaluation");
            }
            else
            {
                for (int i = 0; i < enrolments.Length; i++)
                {
                    if (enrolments[i] == null)
                        break;
                    else if (enrolments[i].student.registrationNumber == student.registrationNumber)
                    {
                        enrolments[i].evaluations[order - 1].points = points;
                    }

                }
            }
        }

        public string GetEvaluationsInfo()
        {
            string text = "";

            //Header
            for (int j = 0; j < currentNumOfEvaluations; j++)
            {
                text += $"\t{j}." + $"{enrolments[j].evaluations[j].type}" + $"[{enrolments[j].evaluations[j].maxPoints}]";
            }

            //Table
            for (int j = 0; j < currentNumOfEvaluations; j++)
            {
                text += $"\n{enrolments[j].student.Name}";
                for (int k = 0; k < currentNumOfEvaluations; k++)
                {
                    double score = CalculateGrade(enrolments[j].evaluations[k].points, enrolments[j].evaluations[k].maxPoints, enrolments[j].evaluations[k].evaluationWeight);
                    text += String.Format("\t{0}/{1}\t", enrolments[j].evaluations[k].points, score * 100);
                    //text += $"\t{enrolments[j].evaluations[k].points}/" + $"{enrolments[j].evaluations[k].points * enrolments[j].evaluations[k].evaluationWeight}\t\t";
                }
            }

            return text;
        }

        public double CalculateGrade(double points, double maxPoints, double weight)
        {
            return (points / maxPoints) * weight;
        }

        public string FinalMarksInfo()
        {
            string text = "";
            
            for (int j = 0; j < currentNumOfEvaluations; j++)
            {
                text += String.Format("{0}\t{1}\n", enrolments[j].student.Name, enrolments[j].CalculateFinalGrade());
            }

            return text;
        }

        public string ShowAllStudents()
        {
            int i = 0;
            string text = "";

            if (enrolments[i] == null)
                return "";

            while (enrolments[i] != null)
            {
                text += "\n" + enrolments[i].student.Name;
                i++;
            }

            return text;
        }
        
        public string GetInfo()
        {
            if (Faculty != null)
            {
                return String.Format("\nSection Id:{0}, Name: {1}, Max no. of Students: {2}, Semester: {3}, Faculty: {4}\nNumber of Students: {5}\n{6}"
                      , SectionId, Name, MaxNumberOfStudents, Semester, Faculty.Name, currentNumberOfEnrolments, ShowAllStudents());
            }
            else
                return String.Format("\nSection Id:{0}, Name: {1}, Max no. of Students: {2}, Semester: {3}, Faculty: \nNumber of Students: {4}\n{5}"
                     , SectionId, Name, MaxNumberOfStudents, Semester, currentNumberOfEnrolments, ShowAllStudents());
                        
        }

        #endregion
    }
}

