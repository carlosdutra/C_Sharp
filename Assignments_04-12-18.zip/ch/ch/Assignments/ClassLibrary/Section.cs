﻿using Assignment3A.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    [Serializable]

    public class Section
    {
        #region FIELDS
        private string sectionId;
        private string name;
        private int maxNumberOfStudents = 40;
        public SemesterPeriod Semester;
        private Teacher faculty = new Teacher();
        private Course course = new Course();
        public List<Enrolment> enrolments = new List<Enrolment>();
        private int enrolmentsNumber; //5d
        public int currentNumberOfEnrolments = 0;
        public int currentNumOfEvaluations = 0;
        #endregion

        //Class under test  
        public const string PointsAreGreaterThanMaxPoints = "Points are more than the max number of points for the evaluation";
        public const string SectionIsFull = "Student cannot be added. The section is full!";

        #region PROPERTIES

        public string SectionId
        {
            get { return sectionId; }
            set { sectionId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int MaxNumberOfStudents
        {
            get { return maxNumberOfStudents; }
            set { maxNumberOfStudents = value; }
        }

        public Teacher Faculty
        {
            get { return faculty; }
            set { faculty = value; }
        }

        public Course Course
        {
            get { return course; }
            set { course = value; }
        }

        public List<Enrolment> Enrolments
        {
            get { return enrolments; }
        }

        #endregion

        #region CONSTRUCTORS
        public Section()
        {
            SectionId = null;
            Name = null;
            MaxNumberOfStudents = 40;
            Semester = SemesterPeriod.UNDEFINED;
            Course = null;
            enrolments = new List<Enrolment>();
            enrolmentsNumber++;

            //Faculty.TeacherSections.Add(this);
            Faculty.AddSectionToTeacher(this);
        }

        public Section(Course course, int maxNumberOfStudents, SemesterPeriod semester)
        {
            this.Course = course;
            this.MaxNumberOfStudents = maxNumberOfStudents;
            this.Semester = semester;
            enrolments = new List<Enrolment>();
            enrolmentsNumber++;

            //Faculty.TeacherSections.Add(this);
            Faculty.AddSectionToTeacher(this);
        }

        public Section(int maxNumberOfEnrollments, SemesterPeriod semester)
        {
            // 2.c.
            if (maxNumberOfEnrollments == 0)
                maxNumberOfEnrollments = 40;

            this.MaxNumberOfStudents = maxNumberOfEnrollments;
            this.Semester = semester;

            //Faculty.TeacherSections.Add(this);
            Faculty.AddSectionToTeacher(this);
            enrolments = new List<Enrolment>();
            enrolmentsNumber++;
        }
        #endregion

        #region METHODS

        public void AddStudent(Student student)
        {
            Enrolment newEnrolment = new Enrolment(student, this, Grade.NO_GRADE, Course.NoOfEvaluations);

            student.AddStudentToList(this);

            if (currentNumberOfEnrolments + 1 > MaxNumberOfStudents)
                throw new Exception("Student cannot be added. The section is full!");
            else
            {
                //enrolments[currentNumberOfEnrolments++] = newEnrolment;
                enrolments.Add(newEnrolment);
                currentNumberOfEnrolments++;                
            }
        }

        public void DefineEvaluation(int order, EvaluationType type, int maxPoints, double weight)
        {
            //for (int i = 0; i < currentNumberOfEnrolments; i++)
            //{
            foreach (Enrolment enrolment in enrolments)
            {
                enrolment.evaluations.Add(new Evaluation(type, weight, maxPoints));
            }
            //}

            currentNumOfEvaluations++;
        }
        
        public void AddStudentMark(int order, Person student, int points)
        {
            //for (int i = 0; i < currentNumberOfEnrolments; i++)
            //{
            //if (enrolments[i] == null)
            //    break;
            foreach (Enrolment enrolment in enrolments)
            {
                if (points > enrolment.evaluations[order - 1].maxPoints) 
                {
                    throw new Exception("Points are more than the max number of points for the evaluation"); 
                }
                else if (enrolment.student.registrationNumber == student.registrationNumber)
                {
                    enrolment.evaluations[order - 1].points = points;
                }
            }
            
        }

        public string GetEvaluationsInfo()
        {
            string text = "";

            //Header
            for (int j = 0; j < currentNumOfEvaluations; j++)
            {
                text += $"\t{j}." + $"{enrolments[0].evaluations[j].type}" + $"[{enrolments[0].evaluations[j].maxPoints}]";
            }

            //Table
            //for (int j = 0; j < currentNumOfEvaluations; j++)
            //{
            foreach (Enrolment enrolment in enrolments)
            {
                text += $"\n{enrolment.student.Name}";
                for (int k = 0; k < currentNumOfEvaluations; k++)
                {
                    double score = CalculateGrade(enrolment.evaluations[k].points, enrolment.evaluations[k].maxPoints, enrolment.evaluations[k].evaluationWeight);
                    text += String.Format("\t{0}/{1}\t", enrolment.evaluations[k].points, score * 100);
                    //text += $"\t{enrolments[j].evaluations[k].points}/" + $"{enrolments[j].evaluations[k].points * enrolments[j].evaluations[k].evaluationWeight}\t\t";
                }
            }

            return text;
        }

        public double CalculateGrade(double points, double maxPoints, double weight)
        {
            return (points / maxPoints) * weight;
        }

        public string FinalMarksInfo()
        {
            string text = "";

            //for (int j = 0; j < currentNumberOfEnrolments; j++)
            //{
            foreach (Enrolment enrolment in enrolments)
            {
                text += String.Format("{0}\t{1}\n", enrolment.student.Name, enrolment.CalculateFinalGrade());
            }

            return text;
        }

        public string ShowAllStudents()
        {
            //int i = 0;
            string text = "";

            //if (enrolments[i] == null)
            //    return "";

            //while (enrolments[i] != null)
            //{
                //text += "\n" + enrolments[i].student.Name;
                //i++;
            //}

            foreach (Enrolment enrolment in enrolments)
            {
                text += "\n" + enrolment.student.Name;
            }


            return text;



        }
        
        public override string ToString()
        {
            if (Faculty != null)
            {
                return String.Format("\nSection Id:{0}, Name: {1}, Max no. of Students: {2}, Semester: {3}, Faculty: {4}\nNumber of Students: {5}\n{6}"
                      , SectionId, Name, MaxNumberOfStudents, Semester, Faculty.Name, currentNumberOfEnrolments, ShowAllStudents());
            }
            else
                return String.Format("\nSection Id:{0}, Name: {1}, Max no. of Students: {2}, Semester: {3}, Faculty: \nNumber of Students: {4}\n{5}"
                     , SectionId, Name, MaxNumberOfStudents, Semester, currentNumberOfEnrolments, ShowAllStudents());
                        
        }

        #endregion
    }
}

