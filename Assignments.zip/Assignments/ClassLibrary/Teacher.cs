﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    [Serializable]
    public class Teacher : Person
    {
        List<Section> teacherSections = new List<Section>();

        #region CONSTRUCTORS
        public Teacher() : base()
        {
            
        }

        public Teacher(string name, DateTime dob)
        {
            base.Name = name;
            base.DOB = dob;
        }

        public List<Section> TeacherSections
        {
            get { return teacherSections; }
            set { teacherSections = value; }
        }
        #endregion

        public void AddSectionToTeacher(Section section)
        {
            teacherSections.Add(section);
        }

        public string SectionsInfo()
        {
            string text = "";
            string title = "\nSections that Faculty teaches:\n";

            foreach(Section sections in teacherSections)
            {
                text += "\n" + sections.Name;
            }

            return title + text;
        }

    }
}
