﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2A
{
    public struct Address
    {
        string streetName;
        string city;
        string province;

        public Address(string streetName, string city, string province)
        {
            this.streetName = streetName;
            this.city = city;
            this.province = province;
        }
    }
}
