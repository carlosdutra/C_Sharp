﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment3A;
using System.IO;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        #region TestMethodsSectionClass
        [TestMethod]
        public void AddStudentMark_PointsGreaterThanMaxPoints_ThrowAnError()
        {
            //Arrange
            Student student = new Student();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section() { Course = testCourse };

            //Act
            aSection.AddStudent(student);
            aSection.DefineEvaluation(1, EvaluationType.TEST, 100, .5);

            try
            {
                aSection.AddStudentMark(1, student, 101);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Section.PointsAreGreaterThanMaxPoints);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void AddStudentMark_StudentIsNotInTheSection_ThrowAnError()
        {
            //Arrange
            Student student1 = new Student() { Name = "Michael" };
            Student student2 = new Student() { Name = "Scott" };
            Course testCourse = new Course() { NoOfEvaluations = 1 };
            Section section1 = new Section() { Course = testCourse };
            Section section2 = new Section() { Course = testCourse };

            //Act
            section1.AddStudent(student1);
            section2.AddStudent(student2);
            section1.DefineEvaluation(1, EvaluationType.TEST, 100, .5);
            section2.DefineEvaluation(1, EvaluationType.TEST, 100, .5);

            try
            {
                section1.AddStudentMark(1, student2, 50);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Section.StudentIsNotInTheSection);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void AddStudent_TryingToAddStudentToFullSection_ThrowAnError()
        {
            //Arrange
            Student student1 = new Student();
            Student student2 = new Student();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section()
            {
                Course = testCourse,
                MaxNumberOfStudents = 1
            };

            //Act
            aSection.AddStudent(student1);

            try
            {
                aSection.AddStudent(student2);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Section.SectionIsFull);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void CalculateGrade_WithValidValues_ShouldReturnValueExpected()
        {
            //Arrange
            Section aSection = new Section();
            double expected = 0.528d;

            //Act
            double actual = aSection.CalculateGrade(88, 100, .6);

            //Assert
            Assert.AreEqual(expected, actual, 0.001, "Grade was calculated correctly!");
        }

        [TestMethod]
        public void CalculateFinalGrade_StudentWithGradesA_ShouldReturnGradeA()
        {
            //Arrange
            Student student = new Student();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section() { Course = testCourse };
            Enrolment aEnrolment = new Enrolment(student, aSection, Grade.NO_GRADE, 3);
            Grade expected = Grade.A;

            //Act
            aSection.AddStudent(student);

            aSection.DefineEvaluation(1, EvaluationType.TEST, 100, .5);
            aSection.DefineEvaluation(2, EvaluationType.LAB, 80, .3);
            aSection.DefineEvaluation(3, EvaluationType.QUIZ, 20, 0.2);

            aSection.AddStudentMark(1, student, 90);
            aSection.AddStudentMark(2, student, 70);
            aSection.AddStudentMark(3, student, 15);

            Grade actual = aSection.Enrolments[0].CalculateFinalGrade(); //Calculate the Final Grade

            //Assert
            Assert.AreEqual(expected, actual);
        }
        #endregion

        #region TestMethodsCourseClass
        [TestMethod]
        public void AddSection_SectionWithIdAndNameNulls_ShouldThrownAnException()
        {
            //Arrange
            Student student = new Student();
            Course testCourse = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section();

            //Act
            try
            {
                testCourse.AddSection(aSection);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Course.SectionIsNotValid);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void AddSection_TryToAddSectionAlreadyAssignedToAnotherCourse_ShouldThrownAnException()
        {
            //Arrange
            Student student = new Student();
            Course testCourse = new Course()
            {
                Name = "COURSE_TEST",
                NoOfEvaluations = 3
            };
            Course testCourse1 = new Course() { NoOfEvaluations = 3 };
            Section aSection = new Section()
            {
                Name = "SECTION_TEST",
                SectionId = "ID_TEST",
                Course = testCourse
            };

            //Act
            try
            {
                testCourse1.AddSection(aSection);
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Course.SectionIsAlreadyAssignedToAnotherCourse);
                return;
            }

            //Assert
            Assert.Fail();
        }

        [TestMethod]
        public void ChangeNoOfEvaluations_SectionIsAlreadyAssignedToTheCourse_ShouldThrownAnException()
        {
            //Arrange
            Course testCourse = new Course() { Name = "COURSE_TEST", NoOfEvaluations = 3 };
            Section aSection = new Section() { Name = "SECTION_TEST", SectionId = "ID_TEST" };

            //Act
            testCourse.Sections.Add(aSection);

            try
            {
                testCourse.NoOfEvaluations = 5;
            }
            catch (Exception ex)
            {
                StringAssert.Contains(ex.Message, Course.SectionIsAlreadyAssignedCantChangeNoOfEvaluations);
                return;
            }

            //Assert
            Assert.Fail();
        }
        #endregion

        #region TestMethodsCourseManagerClass

        [TestMethod]
        public void ExportCourses_CreatingFile_ShouldReturnExpectedValues()
        {
            //Arrange
            CourseManager courseManager = new CourseManager();
            Course courseTest1 = new Course()
            {
                CourseCode = "TEST01",
                Name = "Course Teste I",
                Description = "Teste 1",
                NoOfEvaluations = 3
            };

            //Act
            courseManager.AddCourse(courseTest1);

            courseManager.ExportCourses("CourseManagerUnitTest.txt", '/');

            string[] lines = File.ReadAllLines("CourseManagerUnitTest.txt");

            string text = "";
            foreach (string line in lines)
            {
                string[] dataEntries = line.Split('/');
                text = dataEntries[0] + "/" + dataEntries[1] + "/" + dataEntries[2] + "/" + dataEntries[3];
            }

            string actual = text;
            string expected = "TEST01/Course Teste I/Teste 1/3";

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void SaveSchoolInfo_SavingAndCheckingIfFileWasSaved_ShouldReturnTrue()
        {
            //Arrange
            CourseManager courseManager = new CourseManager();
            Course courseTest1 = new Course()
            {
                CourseCode = "TEST01",
                Name = "Course Teste I",
                Description = "Teste 1",
                NoOfEvaluations = 3
            };
            bool exists = false;

            //Act
            try
            {
                courseManager.AddCourse(courseTest1); //Adding the course
                courseManager.SaveSchoolInfo(); //Save info into user.dat

                exists = File.Exists("user.dat"); //Verify if the files was cretead and saved. If it's true therefore the method works.
            }
            catch (FileNotFoundException ex)
            {
                throw ex;
            }

            //Assert
            Assert.IsTrue(exists);
        }

        [TestMethod]
        public void LoadSchool_LoadFileAndSerializeIntoCoursesList_ShouldReturnTrue()
        {
            //Arrange
            CourseManager courseManager1 = new CourseManager();
            CourseManager courseManager2 = new CourseManager();
            Course courseTest1 = new Course()
            {
                CourseCode = "TEST01",
                Name = "Course Teste I",
                Description = "Teste 1",
                NoOfEvaluations = 3
            };
            Course courseTest2 = new Course()
            {
                CourseCode = "TEST02",
                Name = "Course Teste 2",
                Description = "Teste 2",
                NoOfEvaluations = 6
            };

            bool works = false;
            
            //Act
            try
            {
                courseManager1.AddCourse(courseTest1); //Adding the course
                courseManager1.AddCourse(courseTest2); //Adding the course
                courseManager1.SaveSchoolInfo(); //Save info into user.dat
                courseManager2.LoadSchool("user.dat"); //Load Info

                if (courseManager2.Courses.Count != 0)
                    works = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            //Assert
            Assert.IsTrue(works);
        }

        #endregion
    }
}
