﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Letter Percentage	4.5 Scale
//A+	90-100	4.5
//A	    80-89	4
//B+	75-79	3.5
//B	    70-74	3
//C+	65-69	2.5
//C	    60-64	2
//D+	55-59	1.5
//D	    50-54	1
//F	    0-49	0

namespace Assignment3A
{
    public enum Grade
    {
        NO_GRADE,
        F,
        D,
        D_Plus,
        C,
        C_Plus,
        B,
        B_Plus,
        A, 
        A_Plus
    }
}
