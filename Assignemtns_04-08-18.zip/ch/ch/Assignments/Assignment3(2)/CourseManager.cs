﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    [Serializable]

    class CourseManager
    {
        Course[] courses = new Course[100];
        public int numberOfCourses;

        public Course[] Courses
        {
            get { return courses; }
        }

        public int NumberOfCourses
        {
            get { return numberOfCourses; }
            set { numberOfCourses = value; }
        }

        public CourseManager()
        {
            numberOfCourses = 0;
        }

        public void AddCourse(Course aCourse)
        {
            Courses[numberOfCourses++] = aCourse;
        }

        public void ExportCourses(string filename, char delimiter)
        {
            FileStream fileOut = new FileStream(filename, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(fileOut);

            foreach (Course course in courses)
            {
                if (course == null)
                {
                    continue;
                }
                writer.Write("{0}{1}", course.CourseCode, delimiter);
                writer.Write("{0}{1}", course.Name, delimiter);
                writer.Write("{0}{1}", course.Description, delimiter);
                writer.WriteLine("{0}", course.NoOfEvaluations);
            }

            writer.Flush();
            writer.Close();
            fileOut.Close();
        }

        public void ImportCourses(string filename, char delimiter)
        {
            FileStream fileOut = new FileStream(filename, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(fileOut);




            writer.Flush();
            writer.Close();
            fileOut.Close();

        }

        public void SaveSchoolInfo()
        {

        }

        public void LoadSchool(string filename)
        {
        }
          

    }
}