﻿using Assignment2.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Enrolment
    {
        public Person student { get; set; }
        public Section section { get; set; }
        public Grade finalGrade { get; set; }
        public int numberOfEvaluations { get; }
        public int currentNumOfEvaluations = 0;
        public Evaluation[] evaluations { get; set; }

        
        
        public Enrolment(Person student, Section section, Grade finalGrade, 
            int numberOfEvaluations)
        {
            this.student = student;
            this.section = section;
            this.finalGrade = finalGrade;
            this.numberOfEvaluations = numberOfEvaluations;
            this.evaluations = new Evaluation[section.Course.NoOfEvaluations];

        }

        public string GetInfo()
        {
            return $"Student = {student}\n" +
                $"Section = {section}\n" +
                $"FinalGrade = {finalGrade}";
        }

    }
}
