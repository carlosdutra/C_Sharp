﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2A
{
    class Person
    {
        public int registrationNumber { get; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public Address Address { get; set; }
        public uint TelephoneNumber { get; set; }

        public Person()
        {
        }

        public Person(string name, DateTime dOB)
        {
            Name = name;
            DOB = dOB;
        }

        public Person(int registrationNumber, string name, DateTime dob)
        {
            this.registrationNumber = registrationNumber;
            this.Name = name;
            this.DOB = dob;
        }

        public string GetInfo()
        {
            return $"RegistrationNumber = {registrationNumber}\n" +
                $"Name = {Name}\n" +
                $"Dob = {DOB}\n" +
                $"Address = {Address}\n" +
                $"TelephoneNumber = {TelephoneNumber}";
        }

    }
}
