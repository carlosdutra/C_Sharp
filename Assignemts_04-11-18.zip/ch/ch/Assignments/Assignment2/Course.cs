﻿using Assignment2A.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2A
{
    class Course
    {
        public string CourseCode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int NoOfEvaluations { get; set; }
        public Section[] sections = new Section[100];
        private int sectionNumber = 0;

        public Course()
        {
        }

        public Course(string courseCode, string name)
        {
            CourseCode = courseCode;
            Name = name;
        }

        public string GetInfo()
        {
            return $"CourseCode = {CourseCode}\n" +
                $"Name = {Name}\n" +
                $"Description = {Description}\n" +
                $"NoOfEvaluations = {NoOfEvaluations}";
        }

        public void AddSection(SemesterPeriod semesterPeriod, string SectionId, string sectionName)
        {
            Section newSection = new Section(30, semesterPeriod);
            newSection.SectionId = SectionId;
            newSection.Name = sectionName;

            // Add to sections
            sections[sectionNumber++] = newSection;
        }

        public void AddSection(Section newSection)
        {
            // Validation 1
            if (newSection.SectionId == null || newSection.Name == null)
            {
                throw new Exception("Section is not valid");
            }

            // Validation 2
            bool exists = false;
            foreach (Section section in sections)
            {
                if (section.SectionId == newSection.SectionId)
                {
                    exists = true;
                    break;
                }
            }
            if (exists)
            {
                throw new Exception("“Section already assigned to this course");
            }


            // Add to sections
            sections[sectionNumber++] = newSection;
        }
    }
}
