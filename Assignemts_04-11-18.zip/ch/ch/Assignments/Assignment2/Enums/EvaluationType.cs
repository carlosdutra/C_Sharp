﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2A.Enums
{
    public enum EvaluationType
    {
        TEST,
        QUIZ,
        ASSIGNMENT,
        LAB
    }
}
