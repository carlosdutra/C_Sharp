﻿using Assignment1.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Course
            Course course = new Course(10, "Software Engineering");
            course.description = "Test";
            Console.WriteLine("-----------");
            Console.WriteLine(course.GetInfo());

            // Section
            Section section = new Section(50, Semester.FALL);
            section.faculty = "Adib";
            section.name = "004";
            section.noOfEvaluations = 10;
            section.sectionId = "654";
            Console.WriteLine("\n-----------");
            Console.WriteLine(section.GetInfo()+"\n");

            // Enrolment
            Enrolment enrolment = new Enrolment("Carlos Henrique", section);
            enrolment.finalGrade = Grade.A_Plus;
            Console.WriteLine("\n-----------");
            Console.WriteLine(enrolment.GetInfo() + "\n");

            // Evaluation
            Evaluation evaluation = new Evaluation(EvaluationType.Assignment, 50, 100);
            evaluation.points = 90;
            Console.WriteLine("\n-----------");
            Console.WriteLine(evaluation.GetInfo() + "\n");

            // Person
            Person person = new Person(100, "Carlos Henrique", new DateTime(1989, 2, 3));
            person.address = new Address("612 Dawes Rd.", "506", "M4B 2G8");
            person.telephoneNumber = "4169800987";
        }
    }
}
