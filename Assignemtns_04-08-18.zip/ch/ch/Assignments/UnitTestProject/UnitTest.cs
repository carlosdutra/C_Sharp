﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment3A;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMethod()
        {

            void AddStudentMark_PointsGreaterThanMaxPoints_UpdatesBalance()
            {
                //Arrange

                Person student = new Person();
                Section aSection = new Section();

                //Act
                try
                {
                    aSection.AddStudentMark(1, student, 101);
                }
                catch (Exception ex)
                {
                    StringAssert.Contains(ex.Message);
                    return;
                }

                Assert.Fail();
                        
            }
            
        }
    }
}
