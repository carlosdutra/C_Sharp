﻿using Assignment3A.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    [Serializable]

    public class Course
    {
        #region FIELDS
        private string courseCode;
        private string name;
        private string description;
        private int noOfEvaluations;
        public Section[] sections; //4.a
        private int maxNumberOfSections = 20;
        private int numberOfSections; //4.b
        private int currentNumberOfSections = 0;
        #endregion

        //Class under test
        public const string SectionIsNotValid = "\nSection is not valid";
        public const string SectionIsAlreadyAssignedToAnotherCourse = "Section already assigned to COURSE_TEST course";

        #region PROPERTIES

        public string CourseCode
        {
            get { return courseCode; }
            set { courseCode = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int NoOfEvaluations
        {
            get { return noOfEvaluations; }

            set
            {
                if (Sections[0] == null)
                    noOfEvaluations = value;
                else
                    throw new Exception("Section is already assigned. Number of evaluations cannot be changed any more");
            }

        }

        public int NumberOfSections
        {
            get { return numberOfSections; }
        }

        public Section[] Sections
        {
            get { return sections; }
            set { sections = value; }
        }


        #endregion

        #region CONSTRUCTORS        
        public Course()
        {
            sections = new Section[maxNumberOfSections];
            numberOfSections++;
        }

        public Course(string courseCode, string name)
        {
            sections = new Section[maxNumberOfSections];
            numberOfSections++;

            CourseCode = courseCode;
            Name = name;
        }
        #endregion

        #region METHODS
        public void AddSection(SemesterPeriod semesterPeriod, string SectionId, string sectionName) //4.c.i
        {
            Section newSection = new Section(30, semesterPeriod);
            newSection.SectionId = SectionId;
            newSection.Name = sectionName;


            // Add to sections

            sections[currentNumberOfSections] = newSection;
            currentNumberOfSections++;

            newSection.Course = this;
        }

        public void AddSection(Section newSection)
        {
            // Validations
            if (newSection.SectionId == null || newSection.Name == null)
                throw new Exception("\nSection is not valid");
            else if (newSection.Course != null)
                throw new Exception("Section already assigned to " + $"{newSection.Course.Name}" + " course");
            else
            {
                sections[currentNumberOfSections] = newSection;
                currentNumberOfSections++;
                newSection.Course = this;
            }
        }

        public string ShowAllSections()
        {
            int i = 0;
            string text = "";

            if (sections[i] == null)
                return "";

            while (sections[i] != null)
            {
                text += "\n" + sections[i].Course.Name + ": " + sections[i].Name;
                i++;
            }

            return text;
        }

        public override string ToString()
        {
            return String.Format("\nCourse Code: {0}, Name: {1}, Description: {2}, No. of Evaluations: {3}\nNo. of Sections: {4}\n{5}", CourseCode, Name, Description, NoOfEvaluations, currentNumberOfSections, ShowAllSections());
        }

        #endregion
    }
}