﻿using Assignment2A.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2A
{
    class Enrolment
    {
        public Person student { get; set; }
        public Section section { get; set; }
        public Grade finalGrade { get; set; }
        public int numberOfEvaluations { get; }
        public Evaluation[] evaluations { get; }

        public Enrolment(Person student, Section section, Grade finalGrade, 
            int numberOfEvaluations)
        {
            this.student = student;
            this.section = section;
            this.finalGrade = finalGrade;
            this.numberOfEvaluations = numberOfEvaluations;
            this.evaluations = new Evaluation[numberOfEvaluations];
        }

        public string GetInfo()
        {
            return $"Student = {student}\n" +
                $"Section = {section}\n" +
                $"FinalGrade = {finalGrade}";
        }

    }
}
