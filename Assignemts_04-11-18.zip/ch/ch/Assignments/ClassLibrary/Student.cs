﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    public class Student : Person
    {
        List<Section> studentSections = new List<Section>();

        public void AddStudentToList(Section section)
        {
            studentSections.Add(section);
        }




        public string PrintTranscript()
        {
            return "";
        }
    }
}
