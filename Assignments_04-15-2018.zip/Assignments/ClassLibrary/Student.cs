﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    [Serializable]
    public class Student : Person
    {
        List<Section> studentSections = new List<Section>();

        public void AddStudentToList(Section section)
        {
            this.studentSections.Add(section);
        }
        
        public string PrintTranscript()
        {
            string text = "";
            
            foreach (Section section in studentSections)
            {
                for (int i = 0; i < section.currentNumberOfEnrolments; i++)
                {
                    if (section.Enrolments[i].student.registrationNumber == this.registrationNumber)
                        text += "\n" + section.Course.CourseCode + " " + section.Enrolments[i].CalculateFinalGrade();
                }
            }

            return text;
        }
    }
}
