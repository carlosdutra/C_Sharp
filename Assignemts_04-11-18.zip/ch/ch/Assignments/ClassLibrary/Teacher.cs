﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A
{
    public class Teacher : Person
    {
        List<Section> teacherSections = new List<Section>();

        public Teacher(string name, DateTime dob)
        {
            base.Name = name;
            base.DOB = dob;
        }

        public string SectionsInfo()
        {
            string text = "";
            string title = "\tSections that Faculty teaches:\n";

            foreach(Section sections in teacherSections)
            {
                text += "\n" + sections;
            }

            return title + text;
        }

    }
}
